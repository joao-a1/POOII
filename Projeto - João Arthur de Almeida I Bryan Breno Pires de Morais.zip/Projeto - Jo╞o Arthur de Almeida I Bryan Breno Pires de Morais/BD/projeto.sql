DROP SCHEMA Livraria;

CREATE SCHEMA IF NOT EXISTS Livraria; 
USE Livraria;

CREATE TABLE IF NOT EXISTS Livro(
id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
ISBN VARCHAR(100) NOT NULL,
titulo VARCHAR(200) NOT NULL,
autor VARCHAR(300) NOT NULL,
data_pub VARCHAR(10) NOT NULL,
nmr_pag INT NOT NULL,
linguagem VARCHAR(50),
valor_unidade DOUBLE NOT NULL)
ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Forma_Pagamento(
id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nome VARCHAR(50) NOT NULL)
ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Cliente(
id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
CPF VARCHAR(14),
nome VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Venda(
id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
data_hora DATETIME NOT NULL,
id_livro INT NOT NULL,
id_cliente INT NOT NULL,
id_forma_pagamento INT NOT NULL,
FOREIGN KEY (id_livro) REFERENCES Livro(id),
FOREIGN KEY (id_cliente) REFERENCES Cliente(id),
FOREIGN KEY (id_forma_pagamento) REFERENCES Forma_Pagamento(id))
ENGINE=InnoDB;


/*
INSERT INTO Cliente VALUES (1, "110.006.369-25", 'Leonardo Gustavo'),
(2, "666.666.666-66", 'Paulinho');

INSERT INTO Livro(ISBN, Titulo, Autor, data_pub, nmr_pag, linguagem, valor_unidade)
VALUES 
("12345", 'Titulo', 'Machado de Assis', "2002/01/24", 150, 'Portugues', 20), 
("123ABC", "1984", 'Geoge Orwell', "1949/06/08", 600, 'Inglês', 75);

INSERT INTO Forma_Pagamento (nome) VALUES 
('Cartão de Crédito'), ('PIX');

INSERT INTO Venda VALUES
(1, "2000-10-10 20:22:02", 1, 1, 1),
(2, "2000-10-10 20:22:02", 2, 1, 2);


SELECT * FROM Livro;
SELECT * FROM Cliente;
SELECT * FROM Venda;
SELECT * FROM Forma_Pagamento;


DELETE FROM Venda;
DELETE FROM Livro;
DELETE FROM Cliente;
DELETE FROM Forma_Pagamento;
*/
