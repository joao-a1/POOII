/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.bean;

import DataBase.DBConnect;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Joao
 */
public class Venda {
    
    Integer id;
    Livro livro;
    Cliente cliente;
    Forma_Pagamento forma_pagamento;

    public Venda(Livro livro, Cliente cliente, Forma_Pagamento forma) {
        this.livro = livro;
        this.cliente = cliente;
        this.forma_pagamento = forma;
    }

    public void salvar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        System.out.println(dtf.format(now));
        
        dados.put("id_livro", String.valueOf(livro.getId()));
        dados.put("id_cliente", String.valueOf(cliente.getId()));
        dados.put("id_forma_pagamento", String.valueOf(forma_pagamento.getId()));
        dados.put("data_hora", dtf.format(now));
        
        db.conectar();
        db.insert("Venda", dados);
        db.desconectar();
    }
    
}
