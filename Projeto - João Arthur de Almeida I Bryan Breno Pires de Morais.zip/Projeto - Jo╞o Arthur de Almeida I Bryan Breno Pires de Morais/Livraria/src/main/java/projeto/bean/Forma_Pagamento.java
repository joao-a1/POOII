/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.bean;

import DataBase.DBConnect;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Joao
 */
public class Forma_Pagamento {
    
    private Integer id;
    private String nome;

    public Forma_Pagamento() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void adicionar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();

        dados.put("nome", nome);

        db.conectar();
        db.insert("Forma_Pagamento", dados);
        db.desconectar();
    }

    public void atualizar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();
        Map<String, String> where = new HashMap<>();
        
        dados.put("nome", nome);

        db.conectar();
        db.update("Forma_Pagamento", dados, where);
        db.desconectar();
    }

    public static List<Forma_Pagamento> buscaForma_Pagamento() throws Exception {
        DBConnect db = new DBConnect();
        ResultSet rset;
        List<Forma_Pagamento> formas = new ArrayList<>();

        db.conectar();
        rset = db.executeQuery("SELECT * FROM Forma_Pagamento");

        try {
            while (rset.next()) {
                Forma_Pagamento p = new Forma_Pagamento();
                p.id = rset.getInt("id");
                p.nome = rset.getString("nome");

                formas.add(p);
            }
        } catch (SQLException ex) {
            throw new Exception("Erro ao percorrer resultados!");
        }

        db.desconectar();

        return formas;
    }
    
}
