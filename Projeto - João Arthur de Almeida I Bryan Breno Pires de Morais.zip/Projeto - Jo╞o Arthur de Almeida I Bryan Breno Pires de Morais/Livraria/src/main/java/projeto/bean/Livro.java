/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.bean;

import DataBase.DBConnect;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Joao
 */
public class Livro {
    
    private Integer id;
    private String ISBN;
    private String titulo;
    private String autor;
    private String data_pub;
    private int nmr_pag;
    private String linguagem;       
    private Double valor_unidade;

    public Livro() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getData() {
        return data_pub;
    }

    public void setData(String data_pub) {
        this.data_pub = data_pub;
    }

    public int getPaginas() {
        return nmr_pag;
    }

    public void setPaginas(int nmr_pag) {
        this.nmr_pag = nmr_pag;
    }

    public String getLinguagem() {
        return linguagem;
    }

    public void setLinguagem(String linguagem) {
        this.linguagem = linguagem;
    }

    public Double getValor() {
        return valor_unidade;
    }

    public void setValor(Double valor_unidade) {
        this.valor_unidade = valor_unidade;
    }
    
    

    public void adicionar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();

        dados.put("ISBN", ISBN);
        dados.put("titulo", titulo);
        dados.put("autor", autor);
        dados.put("data_pub", data_pub);
        dados.put("nmr_pag", String.valueOf(nmr_pag));
        dados.put("linguagem", linguagem);
        dados.put("valor_unidade", String.valueOf(valor_unidade));

        db.conectar();
        db.insert("Livro", dados);
        db.desconectar();
    }

    public void atualizar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();
        Map<String, String> where = new HashMap<>();

        dados.put("ISBN", ISBN);
        dados.put("titulo", titulo);
        dados.put("autor", autor);
        dados.put("data_pub", data_pub);
        dados.put("nmr_pag", String.valueOf(nmr_pag));
        dados.put("linguagem", linguagem);
        dados.put("valor_unidade", String.valueOf(valor_unidade));
        where.put("id", String.valueOf(id));

        db.conectar();
        db.update("Livro", dados, where);
        db.desconectar();
    }

    public static List<Livro> buscaLivros() throws Exception {
        DBConnect db = new DBConnect();
        ResultSet rset;
        List<Livro> books = new ArrayList<>();

        db.conectar();
        rset = db.executeQuery("SELECT * FROM Livro");

        try {
            while (rset.next()) {
                Livro p = new Livro();
                p.id = rset.getInt("id");
                p.ISBN = rset.getString("ISBN");
                p.titulo = rset.getString("titulo");
                p.autor = rset.getString("autor");
                p.data_pub = rset.getString("data_pub");
                p.nmr_pag = rset.getInt("nmr_pag");
                p.linguagem = rset.getString("linguagem");
                p.valor_unidade = rset.getDouble("valor_unidade");

                books.add(p);
            }
        } catch (SQLException ex) {
            throw new Exception("Erro ao percorrer resultados!");
        }

        db.desconectar();

        return books;
    }
    
}
