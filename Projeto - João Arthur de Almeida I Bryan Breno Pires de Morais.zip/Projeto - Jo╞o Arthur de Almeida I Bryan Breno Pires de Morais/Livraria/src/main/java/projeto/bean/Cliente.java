/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.bean;

import DataBase.DBConnect;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Joao
 */
public class Cliente {
    
    private Integer id;
    private String CPF;
    private String nome;

    public Cliente() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void adicionar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();

        dados.put("CPF", CPF);
        dados.put("nome", nome);

        db.conectar();
        db.insert("Cliente", dados);
        db.desconectar();
    }

    public void atualizar() throws Exception {
        DBConnect db = new DBConnect();
        Map<String, String> dados = new HashMap<>();
        Map<String, String> where = new HashMap<>();

        dados.put("CPF", CPF);
        dados.put("nome", nome);
        where.put("id", String.valueOf(id));

        db.conectar();
        db.update("Cliente", dados, where);
        db.desconectar();
    }

    public static List<Cliente> buscaCliente() throws Exception {
        DBConnect db = new DBConnect();
        ResultSet rset;
        List<Cliente> clients = new ArrayList<>();

        db.conectar();
        rset = db.executeQuery("SELECT * FROM Cliente");

        try {
            while (rset.next()) {
                Cliente c = new Cliente();
                c.id = rset.getInt("id");
                c.CPF = rset.getString("CPF");
                c.nome = rset.getString("nome");

                clients.add(c);
            }
        } catch (SQLException ex) {
            throw new Exception("Erro ao percorrer resultados!");
        }

        db.desconectar();

        return clients;
    }
    
}
